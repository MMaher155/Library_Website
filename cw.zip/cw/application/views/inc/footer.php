<style>
	.footer {
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		background-color: #4F5D78;
		color: white;
		text-align: center;
	}
</style><footer class="footoption footer">
                <p>&copy; <a href="" target="_blank">Maher Library</a></p>
            </footer>
<script src="<?php echo base_url(); ?>lib/bootstrap/js/bootstrap.js"></script>
</body>
</html>
