<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="<?php echo base_url(); ?>lib/font-awesome/css/font-awesome.css">

       <div class="homesection " >
			<h3>Welcome </h3>
			
		   <div class="row">
			   <div class="col-sm-4"><p></p></div>
		   </div>

	   </div>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>

	   <br>

	   <br>

	   <br>
	   <br>
	   <br>
	   <br>
	   <br>
	   <br>

	   <form action="<?php echo base_url().'library/sendFeedback' ?>" method="POST">
  <label for="lname">Feedback</label>
  <input type="text"  name="feedback" >
  <input type="submit" value="Submit">
</form> 
     <div style="clear:both;"/>
